package ru.kesp.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri

private val Ink = Color(0xFF10151D)
private val Panel = Color(0xFF1B2430)
private val Accent = Color(0xFF68A7FF)
private val Soft = Color(0xFF9AA8BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KespApp() }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KespApp() {
    var current by remember { mutableStateOf("Главная") }
    var signedIn by remember { mutableStateOf(false) }
    var login by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val tabs = listOf("Главная", "Учёба", "Библиотека", "Расписание", "Ссылки")
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Ink, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            if (!signedIn) {
                LoginScreen(login, { login = it }, password, { password = it }) {
                    // UI prototype: real KESP credentials are not validated until the official integration is configured.
                    signedIn = true
                }
            } else {
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        tabs.forEach { tab ->
                            NavigationBarItem(selected = current == tab, onClick = { current = tab },
                                icon = { Icon(when(tab) { "Главная" -> Icons.Default.Home; "Учёба" -> Icons.Default.School; "Библиотека" -> Icons.Default.MenuBook; "Расписание" -> Icons.Default.CalendarMonth; else -> Icons.Default.Link }, tab) },
                                label = { Text(tab, fontSize = 10.sp) })
                        }
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                        Header(current)
                        when (current) {
                            "Главная" -> HomeScreen { current = it }
                            "Учёба" -> StudyScreen()
                            "Библиотека" -> LibraryScreen()
                            "Расписание" -> ScheduleScreen()
                            else -> LinksScreen()
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun Header(title: String) {
    Column(Modifier.padding(top = 18.dp, bottom = 12.dp)) {
        Text("КЭСП", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
    }
}


@Composable
fun LoginScreen(login: String, onLogin: (String) -> Unit, password: String, onPassword: (String) -> Unit, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("КЭСП", color = Accent, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text("Учебное пространство", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Материалы, расписание и учебные разделы — в одном месте.", color = Soft, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
        OutlinedTextField(login, onLogin, label = { Text("Логин") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(password, onPassword, label = { Text("Пароль") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(14.dp)) { Text("Продолжить") }
        Text("Демонстрационный вход. Подключение официальной авторизации КЭСП будет добавлено после получения адреса и условий доступа.", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp))
    }
}


@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)) {
            Column {
                Text("Всё для учёбы — рядом", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Быстрый доступ к учебным разделам и полезным ресурсам.", color = Soft, modifier = Modifier.padding(top = 6.dp))
            }
        }
        listOf("Учёба" to "Специальности, курсы и дисциплины", "Библиотека" to "Учебные материалы и книги", "Расписание" to "Файлы и расписание занятий", "Ссылки" to "ЭИОС и образовательные сервисы").forEach { (name, desc) ->
            MenuCard(name, desc) { onNavigate(name) }
        }
    }
}

@Composable
fun MenuCard(title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(desc, color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
        }
        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Accent)
    }
}

@Composable
fun StudyScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Учебные разделы", color = Soft)
        listOf("Специальности", "Курсы", "Дисциплины", "Электронная информационно-образовательная среда").forEach { MenuCard(it, "Раздел подготовлен для подключения данных колледжа") {} }
        Text("Пока демонстрационные карточки. Реальные учебные данные и вход требуют официального подключения к системе КЭСП.", color = Soft, fontSize = 12.sp)
    }
}
@Composable
fun LibraryScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Учебная библиотека", color = Soft)
        MenuCard("Материалы курса", "Документы и файлы по дисциплинам") {}
        MenuCard("Учебные книги", "Каталог литературы") {}
        Text("Открытие и загрузка документов будет подключено к источнику библиотеки.", color = Soft, fontSize = 12.sp)
    }
}
@Composable
fun ScheduleScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        MenuCard("Моё расписание", "Просмотр расписания занятий") {}
        MenuCard("Файлы расписания", "PDF и другие документы") {}
        Text("Для отображения актуального расписания нужен официальный файл или ссылка КЭСП.", color = Soft, fontSize = 12.sp)
    }
}
@Composable
fun LinksScreen() {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Полезные ресурсы", color = Soft)
        MenuCard("Сайт КЭСП", "Официальный сайт колледжа") { openLink(context, "https://kesp.ru") }
        MenuCard("Юрайт", "Электронная образовательная библиотека") { openLink(context, "https://urait.ru") }
        MenuCard("ЭИОС", "Электронная информационно-образовательная среда") { }
    }
}
private fun openLink(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
