package ru.kesp.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KespMobileScreen() }
    }
}


@Composable
private fun KespMobileScreen() {
    val sections = listOf("Специальность", "Курсы", "Дисциплины", "Библиотека ЭИОС", "Расписание", "Сайт КЭСП", "Юрайт")
    var selected by remember { mutableStateOf("Главная") }
    var studentName by remember { mutableStateOf("Студент") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF79A9FF), background = Color(0xFF10141D), surface = Color(0xFF1A202C))) {
        Scaffold(containerColor = Color(0xFF10141D)) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Text("КЭСП MOBILE", style = MaterialTheme.typography.labelLarge, color = Color(0xFF91B8FF), fontWeight = FontWeight.Bold)
                    Text("Учебная среда", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Добро пожаловать, $studentName", color = Color(0xFFB6C0D0))
                    Spacer(Modifier.height(14.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202B3E)), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("Центральный блок", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("Специальность · Курсы · Дисциплины", color = Color(0xFFB6C0D0))
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { selected = "Мой профиль" }) { Text("Открыть профиль") }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Разделы", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                }
                items(sections) { section ->
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A202C)), shape = RoundedCornerShape(16.dp), onClick = { selected = section }) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(section, color = Color.White, fontWeight = FontWeight.Medium)
                            Text("›", color = Color(0xFF91B8FF))
                        }
                    }
                }
                item {
                    if (selected != "Главная") {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF202B3E)), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(selected, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Раздел демонстрационной версии. Содержимое можно подключить и заполнить данными учебной среды.", color = Color(0xFFB6C0D0))
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}
