# KESP Mobile — test build

A simple Compose-based Android demo shell for the KESP student environment.

## Build APK automatically
1. Create a new GitHub repository and upload all files from this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and click **Run workflow** (or push to `main`).
4. Open the completed run and download the artifact `KESP-Mobile-debug-apk`.
5. Inside the artifact ZIP is `app-debug.apk`; install it on your Android phone.

This demo is not connected to the real KESP system. The login and educational content are not implemented yet.
